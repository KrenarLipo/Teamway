const questions = [
  {
    "question": "You Prefer:",
    "answer1": "Working Alone?",
    "answer1Total": "0",
    "answer2": "Working in groups",
    "answer2Total": "2",
    "answer3": "Both cases, but it depends on the requirements?",
    "answer3Total": "1"
  },
  {
    "question": "How many best friends do you have?",
    "answer1": "From 4 - 10 best friends",
    "answer1Total": "1",
    "answer2": "Up to 2 best friends?",
    "answer2Total": "0",
    "answer3": "More than 12 best friends",
    "answer3Total": "2"
  },
  {
    "question":
      "If you have this three options to take your girfriend/boyfriend in a date. Which one you choose?",
    "answer1": "Lunch on a big Restaurant?",
    "answer1Total": "1",
    "answer2": "Watching a movie in a cinema?",
    "answer2Total": "0",
    "answer3": "Walking in the park and having a conversation",
    "answer3Total": "2"
  },
  {
    "question": "What job do you prefer?",
    "answer1": "Journalist",
    "answer1Total": "2",
    "answer2": "Politician.",
    "answer2Total": "1",
    "answer3":"Programmer.",
    "answer3Total": "0"
  },
  {
    "question": "What do you do in the free time?",
    "answer1": "Watching anime/movies/videos or something else",
    "answer1Total": "0",
    "answer2": "Playing sports with your friends",
    "answer2Total": "2",
    "answer3": "Having a coffee with a friend",
    "answer3Total": "1"
  }
]
